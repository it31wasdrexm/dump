<?php
session_start();
require 'db_connect.php';

$product_id = $_POST['product_id'] ?? 0;
$size = $_POST['size'] ?? '';

// Проверяем данные
if (!$product_id || !$size) {
    die('Неверные данные');
}

$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$product_id]);
$product = $stmt->fetch();

if (!$product) {
    die('Товар не найден');
}

$stmt = $pdo->prepare("SELECT * FROM product_sizes WHERE product_id = ? AND size = ? AND quantity > 0");
$stmt->execute([$product_id, $size]);
$size_info = $stmt->fetch();

if (!$size_info) {
    die('Выбранный размер недоступен');
}

// --- Гостевая корзина ---
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$found = false;

// Проверяем, есть ли уже этот товар и размер в корзине
foreach ($_SESSION['cart'] as &$item) {
    if ($item['product_id'] == $product_id && $item['size'] == $size) {
        $new_quantity = $item['quantity'] + 1;
        if ($new_quantity > $size_info['quantity']) {
            die('Недостаточно товара на складе');
        }
        $item['quantity'] = $new_quantity;
        $found = true;
        break;
    }
}

unset($item); // Разрываем ссылку после foreach

// Если товара нет — добавляем
if (!$found) {
    $_SESSION['cart'][] = [
        'product_id' => $product_id,
        'product_name' => $product['name'],
        'product_code' => 'CODE_' . $product_id,
        'size' => $size,
        'price' => $product['price'],
        'quantity' => 1,
        'image_path' => $product['image_path']
    ];
}

echo 'success';
?>