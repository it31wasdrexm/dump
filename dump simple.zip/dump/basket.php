<?php
session_start();
require 'db_connect.php'; 

// ---- Убираем требование авторизации ----

$items = $_SESSION['cart'] ?? [];
$cartCount = 0;
$totalPrice = 0;

// Подтягиваем актуальные остатки из БД и считаем общую сумму
foreach ($items as &$item) {
    $stmt = $pdo->prepare("SELECT quantity FROM product_sizes WHERE product_id = ? AND size = ?");
    $stmt->execute([$item['product_id'], $item['size']]);
    $item['stock_quantity'] = $stmt->fetchColumn() ?: 0;
    
    $cartCount += $item['quantity'];
    $totalPrice += $item['price'] * $item['quantity'];
}
unset($item);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Корзина | DUMP</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    body {
      margin: 0;
      font-family: 'Comic Sans MS', cursive, sans-serif;
      background: #fff;
      color: #000;
    }
    .main-header {
      background: white;
      color: black;
      padding: 15px 0;
      position: sticky;
      top: 0;
      z-index: 100;
    }
    .header-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 20px;
    }
    .logo {
      font-size: 28px;
      font-weight: bold;
      letter-spacing: 1px;
      position: absolute;
      left: 50%;
      transform: translateX(-50%);
    }
    .logo a {
      color: black;
      text-decoration: none;
      transition: all 0.3s ease;
    }
    .header-icons {
      display: flex;
      gap: 200px;
      margin-left: auto;
    }
    .icon-link {
      color: black;
      font-size: 20px;
      position: relative;
    }
    .icon-badge {
      position: absolute;
      top: -8px;
      right: -8px;
      background-color: #ff5252;
      color: white;
      border-radius: 50%;
      width: 18px;
      height: 18px;
      font-size: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .cart-container {
      max-width: 1200px;
      margin: 4rem auto;
      padding: 0 5%;
    }
    .cart-header {
      text-align: center;
      margin-bottom: 3rem;
    }
    .cart-header h1 {
      font-size: 2.5rem;
      margin-bottom: 1rem;
      position: relative;
      display: inline-block;
    }
    .cart-header h1::after {
      content: '';
      position: absolute;
      bottom: -10px;
      left: 50%;
      transform: translateX(-50%);
      width: 60px;
      height: 3px;
      background: #000;
    }
    .cart-items {
      display: grid;
      gap: 2rem;
    }
    .cart-item {
      display: grid;
      grid-template-columns: 120px 1fr auto;
      gap: 2rem;
      padding: 2rem;
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 5px 20px rgba(0,0,0,0.05);
      transition: transform 0.3s, box-shadow 0.3s;
    }
    .cart-item:hover {
      transform: translateY(-3px);
      box-shadow: 0 8px 25px rgba(0,0,0,0.1);
    }
    .item-image {
      width: 100%;
      height: 140px;
      object-fit: cover;
      border-radius: 8px;
      border: 2px solid #f5f5f5;
    }
    .item-details {
      display: flex;
      flex-direction: column;
      gap: 0.8rem;
    }
    .item-title {
      font-size: 1.2rem;
      font-weight: 700;
    }
    .item-meta {
      color: #666;
      font-size: 0.9rem;
    }
    .item-actions {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 1rem;
    }
    .remove-btn {
      background: none;
      border: none;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      color: #ff4444;
      padding: 0.5rem 1rem;
      border-radius: 6px;
      transition: background 0.3s;
    }
    .remove-btn:hover {
      background: rgba(255, 68, 68, 0.1);
    }
    .cart-summary {
      margin-top: 3rem;
      padding-top: 2rem;
      border-top: 2px solid #f5f5f5;
      text-align: right;
    }
    .total-price {
      font-size: 1.5rem;
      margin-bottom: 1.5rem;
    }
    .checkout-btn {
      background: #000;
      color: #fff;
      padding: 1rem 3rem;
      border: none;
      border-radius: 30px;
      cursor: pointer;
      font-size: 1rem;
      transition: transform 0.3s, opacity 0.3s;
      display: inline-flex;
      align-items: center;
      gap: 0.8rem;
      text-decoration: none;
    }
    .checkout-btn:disabled {
      background: #999;
      cursor: not-allowed;
    }
    .checkout-btn:hover:not(:disabled) {
      transform: translateY(-2px);
      opacity: 0.9;
    }
    .empty-cart {
      text-align: center;
      padding: 4rem 0;
    }
  </style>
</head>
<body>
  <header class="main-header">
    <div class="header-container">
      <div class="logo">
        <a href="index.php">DUMP</a>
      </div>
      
      <div class="header-icons">
        <a href="basket.php" class="icon-link">
          <i class="fas fa-shopping-bag"></i>
          <?php if ($cartCount > 0): ?>
            <span class="icon-badge"><?= $cartCount ?></span>
          <?php endif; ?>
        </a>
      </div>
    </div>
  </header>

  <main class="cart-container">
    <div class="cart-header">
      <h1>Ваша корзина</h1>
    </div>

    <?php if (!empty($items)): ?>
      <div class="cart-items">
        <?php foreach ($items as $index => $item): ?>
          <div class="cart-item">
            <img src="<?= htmlspecialchars($item['image_path']) ?>" class="item-image" alt="<?= htmlspecialchars($item['product_name']) ?>">
            <div class="item-details">
              <h3 class="item-title"><?= htmlspecialchars($item['product_name']) ?></h3>
              <p class="item-meta">Размер: <?= htmlspecialchars($item['size']) ?></p>
              <p class="item-meta">Цена: ₸<?= number_format($item['price'], 2) ?></p>
              <p class="item-meta">Кол-во: <?= $item['quantity'] ?></p>
            </div>
            <div class="item-actions">
              <form method="POST" action="removefromcart.php">
                <input type="hidden" name="product_id" value="<?= $item['product_id'] ?>">
                <input type="hidden" name="size" value="<?= $item['size'] ?>">
                <button type="submit" class="remove-btn">
                  <i class="fas fa-trash-alt"></i> Удалить
                </button>
              </form>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="cart-summary">
        <h2 class="total-price">Итог: ₸<?= number_format($totalPrice, 2) ?></h2>
        <a href="404.php" class="checkout-btn">
          <i class="fas fa-credit-card"></i> Оформить заказ
        </a>
      </div>
    <?php else: ?>
      <div class="empty-cart">
        <h2>Корзина пуста</h2>
        <a href="index.php" style="
            display: inline-block;
            margin-top: 1rem;
            color: #000;
            text-decoration: none;
            border: 2px solid #000;
            padding: 0.5rem 1rem;
          ">
          <i class="fas fa-arrow-left"></i> Вернуться к покупкам
        </a>
      </div>
    <?php endif; ?>
  </main>
</body>
</html>