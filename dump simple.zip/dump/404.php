<?php
session_start();
// Подсчет товаров в корзине для отображения в хедере
$cartCount = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cartCount += $item['quantity'];
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Страница не найдена | DUMP</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Comic Sans MS', cursive, sans-serif;
            background: #fff;
            color: #000;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .main-header {
            background: white;
            color: black;
            padding: 15px 0;
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 2px solid #000;
        }

        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 80px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .logo {
            font-size: 28px;
            font-weight: bold;
            letter-spacing: 1px;
        }

        .logo a {
            color: black;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .logo a:hover {
            color: #333;
        }

        .header-icons {
            display: flex;
            gap: 20px;
        }

        .icon-link {
            color: black;
            font-size: 20px;
            position: relative;
        }

        .icon-badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background-color: #ff5252;
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .error-container {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding: 4rem 2rem;
            background: linear-gradient(135deg, #fff 0%, #f8f8f8 100%);
        }

        .error-content {
            max-width: 600px;
            margin: 0 auto;
        }

        .error-number {
            font-size: 12rem;
            font-weight: bold;
            color: #000;
            line-height: 1;
            margin-bottom: 1rem;
            text-shadow: 8px 8px 0px rgba(0,0,0,0.1);
            position: relative;
            display: inline-block;
        }

        .error-number::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 4px;
            background: #000;
        }

        .error-title {
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 1.5rem;
            color: #000;
            letter-spacing: 1px;
        }

        .error-message {
            font-size: 1.2rem;
            color: #333;
            margin-bottom: 3rem;
            line-height: 1.6;
            max-width: 500px;
        }

        .error-actions {
            display: flex;
            gap: 1.5rem;
            justify-content: center;
            flex-wrap: wrap;
            margin-bottom: 3rem;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.8rem;
            padding: 1rem 2.5rem;
            text-decoration: none;
            border-radius: 30px;
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.3s ease;
            border: 2px solid #000;
        }

        .btn-primary {
            background: #000;
            color: #fff;
        }

        .btn-primary:hover {
            background: #333;
            border-color: #333;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }

        .btn-secondary {
            background: #fff;
            color: #000;
        }

        .btn-secondary:hover {
            background: #000;
            color: #fff;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }

        .error-graphic {
            margin-top: 3rem;
            position: relative;
        }

        .graphic-element {
            width: 200px;
            height: 200px;
            border: 4px solid #000;
            position: relative;
            animation: float 3s ease-in-out infinite;
        }

        .graphic-element::before,
        .graphic-element::after {
            content: '';
            position: absolute;
            background: #000;
        }

        .graphic-element::before {
            width: 4px;
            height: 60px;
            top: -65px;
            left: 50%;
            transform: translateX(-50%);
        }

        .graphic-element::after {
            width: 60px;
            height: 4px;
            top: 50%;
            right: -65px;
            transform: translateY(-50%);
        }

        @keyframes float {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-10px);
            }
        }

        .error-search {
            margin-top: 2rem;
            max-width: 400px;
        }

        .search-box {
            display: flex;
            gap: 0.5rem;
        }

        .search-input {
            flex: 1;
            padding: 0.8rem 1rem;
            border: 2px solid #000;
            border-radius: 25px;
            font-size: 1rem;
            font-family: 'Comic Sans MS', cursive;
            outline: none;
            background: #fff;
        }

        .search-input:focus {
            box-shadow: 0 0 0 3px rgba(0,0,0,0.1);
        }

        .search-btn {
            padding: 0.8rem 1.5rem;
            background: #000;
            color: #fff;
            border: 2px solid #000;
            border-radius: 25px;
            cursor: pointer;
            font-family: 'Comic Sans MS', cursive;
            transition: all 0.3s ease;
        }

        .search-btn:hover {
            background: #333;
            border-color: #333;
        }

        .error-footer {
            margin-top: 3rem;
            padding-top: 2rem;
            border-top: 2px solid #f0f0f0;
            color: #666;
            font-size: 0.9rem;
        }

        @media (max-width: 768px) {
            .error-number {
                font-size: 8rem;
            }
            
            .error-title {
                font-size: 2rem;
            }
            
            .error-message {
                font-size: 1rem;
            }
            
            .error-actions {
                flex-direction: column;
                align-items: center;
            }
            
            .btn {
                width: 200px;
                justify-content: center;
            }
        }

        @media (max-width: 480px) {
            .error-number {
                font-size: 6rem;
            }
            
            .error-title {
                font-size: 1.5rem;
            }
            
            .graphic-element {
                width: 150px;
                height: 150px;
            }
        }
    </style>
</head>
<body>
    <header class="main-header">
        <div class="header-container">
            <div class="logo">
                <a href="index.php">DUMP</a>
            </div>
            
            
        </div>
    </header>

    <main class="error-container">
        <div class="error-content">
            <div class="error-number">404</div>
            <h1 class="error-title">Страница не найдена</h1>
            <p class="error-message">
                К сожалению, страница, которую вы ищете, не существует. 
                Возможно, она была перемещена или удалена.
            </p>
            
         

         

          

            <div class="error-footer">
                <p>Если вы считаете, что это ошибка, свяжитесь с нами
                    /roman15fn@gmail.com
                </p>
            </div>
        </div>
    </main>

    <script>
        // Добавляем интерактивность для графического элемента
        document.addEventListener('DOMContentLoaded', function() {
            const graphic = document.querySelector('.graphic-element');
            
            graphic.addEventListener('mouseenter', function() {
                this.style.animation = 'none';
                setTimeout(() => {
                    this.style.animation = 'float 3s ease-in-out infinite';
                }, 10);
            });

            // Анимация при загрузке страницы
            setTimeout(() => {
                graphic.style.transform = 'scale(1.1)';
                setTimeout(() => {
                    graphic.style.transform = 'scale(1)';
                }, 300);
            }, 500);
        });
    </script>
</body>
</html>