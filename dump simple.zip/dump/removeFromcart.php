<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id']) && isset($_POST['size'])) {
    $product_id = (int)$_POST['product_id'];
    $size = $_POST['size'];

    // --- Удаляем из гостевой корзины ---
    if (isset($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $index => $item) {
            if ($item['product_id'] == $product_id && $item['size'] == $size) {
                unset($_SESSION['cart'][$index]);
                break;
            }
        }
        $_SESSION['cart'] = array_values($_SESSION['cart']); // пересобираем индексы
    }

    header('Location: basket.php');
    exit;
}

header('Location: basket.php');
exit;
?>