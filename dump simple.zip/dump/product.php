<?php
session_start();
require 'db_connect.php';

// Подсчет товаров в корзине
$cartCount = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cartCount += $item['quantity'];
    }
}

$product_id = $_GET['id'] ?? 1;

$stmt = $pdo->prepare("
    SELECT p.*, c.name AS category_name 
    FROM products p
    LEFT JOIN categories c ON p.category = c.id
    WHERE p.id = ?
");
$stmt->execute([$product_id]);
$product = $stmt->fetch();

if (!$product) {
    die('Товар не найден');
}

$image_data = null;
$image_mime = 'image/png';

if (!empty($product['image_path'])) {
    $image_path = $_SERVER['DOCUMENT_ROOT'] . $product['image_path'];
    if (file_exists($image_path)) {
        $image_data = file_get_contents($image_path);
        $image_mime = mime_content_type($image_path);
    }
}

if (!$image_data) {
    $default_path = $_SERVER['DOCUMENT_ROOT'] . '/images/default.jpg';
    if (file_exists($default_path)) {
        $image_data = file_get_contents($default_path);
        $image_mime = mime_content_type($default_path);
    } else {
        $image_data = base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=');
        $image_mime = 'image/png';
    }
}

$base64_image = 'data:' . $image_mime . ';base64,' . base64_encode($image_data);

$sizes = $pdo->prepare("SELECT * FROM product_sizes WHERE product_id = ? AND quantity > 0");
$sizes->execute([$product_id]);
$available_sizes = $sizes->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Comic+Neue:wght@400;700&display=swap" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="css/product.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .notification {
            position: fixed;
            top: 20px;
            right: -300px;
            background: black;
            color: white;
            padding: 20px;
            border: 2px solid white;
            border-radius: 5px;
            transition: right 0.5s ease-in-out;
            z-index: 1000;
        }

        .notification.show {
            right: 20px;
        }
        
        .category-badge {
            position: absolute;
            top: 10px;
            left: 10px;
            background: rgba(0,0,0,0.7);
            color: white;
            padding: 3px 6px;
            border-radius: 4px;
            font-size: 12px;
        }
        
        /* ИСПРАВЛЕННАЯ ШАПКА */
        .main-header {
            background: white !important;
            color: black !important;
            padding: 15px 0 !important;
            position: sticky !important;
            top: 0 !important;
            z-index: 100 !important;
            border-bottom: none !important;
        }
        
        .header-container {
            display: flex !important;
            justify-content: space-between !important;
            align-items: center !important;
            max-width: 1200px !important;
            margin: 0 auto !important;
            padding: 0 20px !important;
            position: relative !important;
        }
        
        .logo {
            font-size: 28px !important;
            font-weight: bold !important;
            letter-spacing: 1px !important;
            position: absolute !important;
            left: 50% !important;
            transform: translateX(-50%) !important;
        }
        
        .logo a {
            color: black !important;
            text-decoration: none !important;
        }
        
        .header-icons {
            position: static !important;
            top: auto !important;
            right: auto !important;
            display: flex !important;
            gap: 20px !important;
            margin-left: auto !important;
            align-items: center !important;
        }
        
        .icon-link {
            color: black !important;
            font-size: 20px !important;
            position: relative !important;
            text-decoration: none !important;
        }

        .icon-badge {
      position: absolute;
      top: -8px;
      right: -8px;
      background-color: #ff5252;
      color: white;
      border-radius: 50%;
      width: 18px;
      height: 18px;
      font-size: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
        
        .container {
            display: flex;
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
            gap: 40px;
        }
        
        .left-column {
            flex: 1;
        }
        
        .right-column {
            flex: 1;
        }
        
        .product-description h1 {
            font-size: 32px;
            margin-bottom: 20px;
        }
        
        .product-price {
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 30px;
        }
        
        .cable-config {
            margin-bottom: 30px;
        }
        
        .cable-choose {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }
        
        .cable-choose button {
            padding: 10px 15px;
            background: #f5f5f5;
            border: 1px solid #ddd;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .cable-choose button:hover {
            background: #e0e0e0;
        }
        
        .cable-choose button.selected {
            background: black;
            color: white;
            border-color: black;
        }
        
        .cart-btn {
            width: 50%;
            padding: 15px;
            background: black;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .cart-btn:hover {
            opacity: 0.9;
        }

        
        
        .left-column img {
            width: 100%;
            max-height: 600px;
            object-fit: contain;
            border: 1px solid white;
            border-radius: 8px;
            display: block; 
            background-color: white; 
            padding: 5px; 
        }
        
        .image-container {
            position: relative;
            background-color: #f9f9f9; 
            border-radius: 8px;
            overflow: hidden;
            min-height: 300px; 
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .left-column img {
            max-width: 100% !important;
            height: auto !important;
            display: block !important;
            visibility: visible !important;
            opacity: 1 !important;
            position: static !important;
            z-index: 100 !important;
        }

        .size-error {
            color: #ff4444;
            font-size: 14px;
            margin-top: 10px;
            display: none;
        }

        .success-message {
            color: #4CAF50;
            font-size: 14px;
            margin-top: 10px;
            display: none;
        }
    </style>
</head>
<body>
    <header class="main-header">
        <div class="header-container">
            <div class="logo">
                <a href="index.php">DUMP</a>
            </div>
            
            <div class="header-icons">
                <a href="basket.php" class="icon-link">
                    <i class="fas fa-shopping-bag"></i>
                    <?php if ($cartCount > 0): ?>
                        <span class="icon-badge" id="cartCount"><?= $cartCount ?></span>
                    <?php endif; ?>
                </a>
            </div>
        </div>
    </header>

    <main class="container">
        <div class="left-column">
            <div class="image-container">
                <div class="category-badge"><?= htmlspecialchars($product['category_name'] ?? '') ?></div>
                <img src="<?= $base64_image ?>" 
                     alt="<?= htmlspecialchars($product['name']) ?>"
                     style="max-width: 100%; height: auto;"> 
            </div>
        </div>

        <div class="right-column">
            <div class="product-description">
                <h1><?= htmlspecialchars($product['name']) ?></h1>
                <div class="product-price">
                    <span>₸<?= number_format($product['price'], 2) ?></span>
                </div>
            </div>

            <div class="product-configuration">
                <div class="cable-config">
                    <span>Размер: <span id="selectedSize">Не выбрано</span></span>
                    <div class="cable-choose">
                        <?php foreach ($available_sizes as $size): ?>
                            <button type="button" 
                                    onclick="selectSize('<?= $size['size'] ?>', this)"
                                    data-quantity="<?= $size['quantity'] ?>">
                                <?= $size['size'] ?> 
                            </button>
                        <?php endforeach; ?>
                    </div>
                    <div id="sizeError" class="size-error">Пожалуйста, выберите размер</div>
                    <div id="successMessage" class="success-message">.</div>
                </div>

                <button type="button" class="cart-btn" id="addToCartBtn" onclick="addToCart()" disabled>Добавить в корзину</button>
            </div>
        </div>
    </main>

    <div id="notification" class="notification">
        Товар добавлен в корзину!
    </div>

    <script>
        let selectedSize = '';
        
        function selectSize(size, button) {
            selectedSize = size;
            document.getElementById("selectedSize").innerText = size;
            
            // Убираем выделение со всех кнопок
            document.querySelectorAll('.cable-choose button').forEach(btn => {
                btn.classList.remove('selected');
            });
            
            // Добавляем выделение выбранной кнопке
            button.classList.add('selected');
            
            // Активируем кнопку добавления в корзину
            document.getElementById('addToCartBtn').disabled = false;
            document.getElementById('sizeError').style.display = 'none';
        }
        
        async function addToCart() {
            if (!selectedSize) {
                document.getElementById('sizeError').style.display = 'block';
                return;
            }

            const formData = new FormData();
            formData.append('product_id', '<?= $product['id'] ?>');
            formData.append('size', selectedSize);
            
            try {
                const response = await fetch('addtocart.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.text();
                
                if (response.ok && result === 'success') {
                    showNotification();
                    updateCartCount();
                    document.getElementById('successMessage').style.display = 'block';
                    setTimeout(() => {
                        document.getElementById('successMessage').style.display = 'none';
                    }, 3000);
                } else {
                    alert('Ошибка: ' + result);
                }
            } catch (error) {
                console.error('Ошибка:', error);
                alert('Произошла ошибка соединения');
            }
        }

        function showNotification() {
            const notification = document.getElementById('notification');
            notification.classList.add('show');
            setTimeout(() => {
                notification.classList.remove('show');
            }, 3000);
        }

        function updateCartCount() {
            // Обновляем счетчик корзины
            const cartBadge = document.querySelector('.icon-badge');
            let currentCount = parseInt(cartBadge?.textContent || 0);
            currentCount++;
            
            if (cartBadge) {
                cartBadge.textContent = currentCount;
            } else {
                // Создаем бейдж если его нет
                const iconLink = document.querySelector('.icon-link');
                const newBadge = document.createElement('span');
                newBadge.className = 'icon-badge';
                newBadge.id = 'cartCount';
                newBadge.textContent = currentCount;
                iconLink.appendChild(newBadge);
            }
        }

        // Добавляем обработчик нажатия Enter на кнопках размера
        document.querySelectorAll('.cable-choose button').forEach(button => {
            button.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    selectSize(this.textContent.trim(), this);
                }
            });
        });
    </script>
</body>
</html>